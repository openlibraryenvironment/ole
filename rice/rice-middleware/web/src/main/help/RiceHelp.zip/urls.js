var g_ContentsURL = "5_0_RiceHelp-toc.htm";
var g_IndexURL = "5_0_RiceHelp-index.htm";
var g_SearchURL = "5_0_RiceHelp-search.htm";
var g_FavoritesURL = "5_0_RiceHelp-favorites.htm";
